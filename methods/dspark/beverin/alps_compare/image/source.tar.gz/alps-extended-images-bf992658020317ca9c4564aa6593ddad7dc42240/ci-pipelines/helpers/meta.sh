#!/usr/bin/env bash
set -euo pipefail

# Depends on skopeo.sh being sourced for registry/marker helpers,
# and IMAGE_PREFIX being set in CI variables.

# Canonical ref and hash helpers shared by CI and manual builds.
#
# Tag model:
# - canonical tags include a deterministic content hash and are build outputs;
# - tested marker tags prove a canonical digest passed the current validation;
# - stable tags are promotion targets and must never be used as app build bases.
#
# Content hashes intentionally exclude timestamps and commit SHAs. OCI labels may
# carry CI metadata, but refs should only change when logical build inputs change.

# Emits sha256sum lines for all files under paths in stable order.
# usage: hash_paths_stream PATH...
hash_paths_stream() {
  [[ "$#" -gt 0 ]] || { echo "ERROR: paths required" >&2; return 1; }
  local path

  # Expand directories to files, keep a stable list, then hash.
  # sort -u ensures stable uniqueness if two roots overlap.
  for path in "$@"; do
    if [[ -d "$path" ]]; then
      # Keep cache/editor artifacts out of both hashes and the build context.
      find "$path" \
        -type d \( -name .git -o -name __pycache__ -o -name .pytest_cache \) -prune -o \
        -type f ! -name '*.pyc' ! -name '*.pyo' ! -name '*.swp' ! -name '*.swo' ! -name '*~' -print0
    else
      printf '%s\0' "$path"
    fi
  done | sort -zu | xargs -0 -r sha256sum
}

# usage: vars_blob "VAR1 VAR2 ..."
vars_blob() {
  local names="${1:?var list required}"
  for n in $names; do
    printf '%s=%s\n' "$n" "${!n-}"
  done | sort
}

# Hash file inputs and selected variables into the short tag hash format used by
# both content hashes and validation hashes.
# usage: short_input_hash "vars..." PATH...
short_input_hash() {
  local vars_to_hash="${1:-}"
  shift || true
  [[ "$#" -gt 0 ]] || { echo "ERROR: paths required" >&2; return 1; }

  {
    hash_paths_stream "$@"
    if [[ -n "$vars_to_hash" ]]; then
      vars_blob "$vars_to_hash"
    fi
  } | sha256sum | awk '{print $1}' | cut -c1-32
}

# Hash content that affects image build output. The stream includes file hashes
# in stable path order and selected logical variables, then truncates the sha256
# for tag readability.
# usage: content_hash "vars..." PATH...
content_hash() {
  local vars_to_hash="${1:?vars required}"
  shift
  short_input_hash "$vars_to_hash" "$@"
}

# usage: validation_hash "vars..." PATH...
validation_hash() {
  local vars_to_hash="${1:-}"
  shift || true
  short_input_hash "$vars_to_hash" "$@"
}

trim_string() {
  local value="${1:-}"
  value="${value#"${value%%[![:space:]]*}"}"
  value="${value%"${value##*[![:space:]]}"}"
  printf '%s\n' "$value"
}

profile_value() {
  local profile_file="${1:?profile file required}"
  local key="${2:?profile key required}"
  local line stripped name value first suffix

  [[ "$key" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || { echo "ERROR: unsafe profile key: $key" >&2; return 1; }
  while IFS= read -r line || [[ -n "$line" ]]; do
    stripped="$(trim_string "$line")"
    [[ -z "$stripped" || "$stripped" == \#* ]] && continue
    if [[ "$stripped" == export[[:space:]]* ]]; then
      stripped="$(trim_string "${stripped#export}")"
    fi
    [[ "$stripped" =~ ^([A-Za-z_][A-Za-z0-9_]*)[[:space:]]*=(.*)$ ]] || continue
    name="${BASH_REMATCH[1]}"
    [[ "$name" == "$key" ]] || continue
    value="$(trim_string "${BASH_REMATCH[2]}")"
    first="${value:0:1}"
    if [[ "$first" == '"' ]]; then
      value="${value#\"}"
      [[ "$value" == *\"* ]] || { echo "ERROR: unterminated double-quoted value for $key in $profile_file" >&2; return 1; }
      suffix="${value#*\"}"
      value="${value%%\"*}"
      suffix="$(trim_string "$suffix")"
      [[ -z "$suffix" || "$suffix" == \#* ]] || { echo "ERROR: unexpected content after quoted value for $key in $profile_file" >&2; return 1; }
    elif [[ "$first" == "'" ]]; then
      value="${value#\'}"
      [[ "$value" == *\'* ]] || { echo "ERROR: unterminated single-quoted value for $key in $profile_file" >&2; return 1; }
      suffix="${value#*\'}"
      value="${value%%\'*}"
      suffix="$(trim_string "$suffix")"
      [[ -z "$suffix" || "$suffix" == \#* ]] || { echo "ERROR: unexpected content after quoted value for $key in $profile_file" >&2; return 1; }
    else
      value="${value%%#*}"
      value="$(trim_string "$value")"
    fi
    printf '%s\n' "$value"
    return 0
  done < "$profile_file"
}
# Validation hashes are separate from image content hashes. They cover test
# declarations and the templates/helpers that implement testing. This lets CI
# re-test an unchanged canonical image when validation logic changes, without
# forcing a rebuild of the image itself.
validation_helper_paths() {
  printf '%s\n' \
    "ci-pipelines/child-templates.yaml" \
    "ci-pipelines/helpers/generate-child-pipeline.py" \
    "ci-pipelines/helpers/meta.sh" \
    "ci-pipelines/helpers/skopeo.sh" \
    "ci-pipelines/helpers/vetnode-config.yaml"
}

base_validation_hash() {
  local family="${1:?family required}"
  local name="${2:?name required}"
  local variant="${3:?variant required}"
  local ci_file

  case "$family" in
    cuda) ci_file="Alps-Images/NGC/ci.yaml" ;;
    rocm) ci_file="Alps-Images/ROCm/ci.yaml" ;;
    *) echo "ERROR: unsupported base family for validation hash: $family" >&2; return 1 ;;
  esac

  local -a helper_paths
  mapfile -t helper_paths < <(validation_helper_paths)
  local -a paths=("$ci_file" "${helper_paths[@]}")
  validation_hash "family name variant" "${paths[@]}"
}

app_validation_hash() {
  local app_name="${1:?app name required}"
  local app_variant="${2:?app variant required}"
  local app_dir="Alps-Images/apps/${app_name}"
  local ci_file="${app_dir}/ci.yaml"
  local profile_file="${app_dir}/profile.env"
  local -a helper_paths
  mapfile -t helper_paths < <(validation_helper_paths)
  local -a paths=("$ci_file" "${helper_paths[@]}")

  [[ -f "$ci_file" ]] || { echo "ERROR: missing $ci_file" >&2; return 1; }
  app_variants_from_profile "$profile_file" "$app_variant" >/dev/null || return 1

  local variant_upper
  variant_upper="$(app_variant_prefix "$app_variant")"
  local test_dir_var="${variant_upper}_TEST_DIR"
  local patch_dir_var="${variant_upper}_PATCH_DIR"
  local common_test_dir common_patch_dir test_dir_rel patch_dir_rel
  common_test_dir="$(profile_value "$profile_file" COMMON_TEST_DIR)"
  common_patch_dir="$(profile_value "$profile_file" COMMON_PATCH_DIR)"
  test_dir_rel="$(profile_value "$profile_file" "$test_dir_var")"
  patch_dir_rel="$(profile_value "$profile_file" "$patch_dir_var")"

  if [[ -n "$common_test_dir" ]]; then
    paths+=("${app_dir}/${common_test_dir}")
  fi
  if [[ -n "$test_dir_rel" ]]; then
    paths+=("${app_dir}/${test_dir_rel}")
  fi
  if [[ -n "$common_patch_dir" ]]; then
    paths+=("${app_dir}/${common_patch_dir}")
  fi
  if [[ -n "$patch_dir_rel" ]]; then
    paths+=("${app_dir}/${patch_dir_rel}")
  fi

  validation_hash "app_name app_variant" "${paths[@]}"
}

# usage: canon_tag_for TAG HASH
canon_tag_for() {
  printf '%s-%s\n' "$1" "$2"
}

# usage: img_ref NAME TAG
img_ref() {
  : "${IMAGE_PREFIX:?IMAGE_PREFIX must be set}"
  printf '%s/%s:%s\n' "$IMAGE_PREFIX" "$1" "$2"
}

# usage: image_refs NAME TAG HASH
# Returns: CANON_REF STABLE_REF
image_refs() {
  local name="${1:?name required}"
  local tag="${2:?tag required}"
  local hash="${3:?hash required}"
  local canon_tag

  canon_tag="$(canon_tag_for "$tag" "$hash")"
  printf '%s %s\n' "$(img_ref "$name" "$canon_tag")" "$(img_ref "$name" "$tag")"
}

# Parse BASE_IMAGE like:
#   pytorch-cuda:25.12-py3 -> prints "ngc pytorch 25.12-py3"
#   pytorch-rocm:rocm7.14-ubuntu24.04-py3.12-torch2.11 -> prints "rocm pytorch rocm7.14-ubuntu24.04-py3.12-torch2.11"
parse_base_image() {
  local base="${1:?BASE_IMAGE required}"
  local repo="${base%%:*}" tag="${base#*:}"

  case "$repo" in
    *-cuda)
      printf 'ngc %s %s\n' "${repo%-cuda}" "$tag"
      ;;
    *-rocm)
      printf 'rocm %s %s\n' "${repo%-rocm}" "$tag"
      ;;
    *)
      echo "ERROR: expected BASE_IMAGE like <name>-cuda:<tag> or <name>-rocm:<tag>, got: $base" >&2
      return 1
      ;;
  esac
}

base_canonical_ref() {
  local family="${1:?family required}"
  local name="${2:?name required}"
  local variant="${3:?variant required}"
  local -a fields

  case "$family" in
    ngc)
      read -r -a fields < <(ngc_base_refs "$name" "$variant")
      printf '%s\n' "${fields[3]}"
      ;;
    rocm)
      read -r -a fields < <(rocm_base_refs "$name" "$variant")
      printf '%s\n' "${fields[2]}"
      ;;
    *)
      echo "ERROR: unsupported base image family: $family" >&2
      return 1
      ;;
  esac
}

rocm_profile_file() {
  local rocm_name="${1:?rocm_name required}"
  local rocm_variant="${2:?rocm_variant required}"

  printf 'Alps-Images/ROCm/%s-%s/profile.env\n' "$rocm_name" "$rocm_variant"
}

rocm_version_from_variant() {
  local rocm_variant="${1:?rocm_variant required}"

  if [[ "$rocm_variant" =~ ^rocm([0-9]+\.[0-9]+)- ]]; then
    printf '%s.0\n' "${BASH_REMATCH[1]}"
    return 0
  fi

  echo "ERROR: can not derive ROCm version from variant: ${rocm_variant}" >&2
  return 1
}

rocm_base_image_ref() {
  local rocm_name="${1:?rocm_name required}"
  local rocm_variant="${2:?rocm_variant required}"

  case "$rocm_name" in
    pytorch)
      if [[ "$rocm_variant" =~ ^rocm([0-9]+\.[0-9]+)-ubuntu([0-9]+\.[0-9]+)-py([0-9]+\.[0-9]+)-torch([0-9]+\.[0-9]+)$ ]]; then
        printf 'docker.io/rocm/pytorch:rocm%s_ubuntu%s_py%s_pytorch_release_%s.0\n' \
          "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}" "${BASH_REMATCH[3]}" "${BASH_REMATCH[4]}"
        return 0
      fi
      ;;
  esac

  echo "ERROR: can not derive ROCm base image ref from ${rocm_name}:${rocm_variant}" >&2
  return 1
}

validate_rocm_profile() {
  local profile_file="${1:?profile_file required}"

  [[ -n "${ROCM_PYPI_INDEX_URL:-}" ]] || { echo "ERROR: ROCM_PYPI_INDEX_URL must be set in $profile_file" >&2; return 1; }
  [[ "${ROCM_REBUILD_RCCL:-0}" == "0" || "${ROCM_REBUILD_RCCL:-0}" == "1" ]] || { echo "ERROR: ROCM_REBUILD_RCCL must be 0 or 1 in $profile_file" >&2; return 1; }
  [[ -n "${ROCM_SYSTEMS_REPO:-}" ]] || { echo "ERROR: ROCM_SYSTEMS_REPO must be set in $profile_file" >&2; return 1; }
  [[ -n "${ROCM_SYSTEMS_COMMIT:-}" ]] || { echo "ERROR: ROCM_SYSTEMS_COMMIT must be set in $profile_file" >&2; return 1; }
  if [[ -n "${ROCM_LIBRARIES_REPO:-}" || -n "${ROCM_LIBRARIES_COMMIT:-}" ]]; then
    [[ -n "${ROCM_LIBRARIES_REPO:-}" && -n "${ROCM_LIBRARIES_COMMIT:-}" ]] || { echo "ERROR: ROCM_LIBRARIES_REPO and ROCM_LIBRARIES_COMMIT must be set together in $profile_file" >&2; return 1; }
  fi
  [[ -n "${RCCL_GPU_TARGETS:-}" ]] || { echo "ERROR: RCCL_GPU_TARGETS must be set in $profile_file" >&2; return 1; }
  [[ -n "${RCCL_TESTS_GPU_TARGETS:-}" ]] || { echo "ERROR: RCCL_TESTS_GPU_TARGETS must be set in $profile_file" >&2; return 1; }
}

load_rocm_profile() {
  local profile_file="${1:?profile_file required}"

  ROCM_PYPI_INDEX_URL=""
  ROCM_REBUILD_RCCL="0"
  ROCM_SYSTEMS_REPO=""
  ROCM_SYSTEMS_COMMIT=""
  ROCM_LIBRARIES_REPO=""
  ROCM_LIBRARIES_COMMIT=""
  RCCL_GPU_TARGETS=""
  RCCL_TESTS_GPU_TARGETS=""
  # shellcheck disable=SC1090
  source "$profile_file"
  validate_rocm_profile "$profile_file"
}

rocm_base_build_args() {
  local rocm_variant_dir="${1:?rocm_variant_dir required}"

  cat <<EOF
  --build-arg ROCM_VARIANT_DIR="$rocm_variant_dir" \\
  --build-arg ROCM_VERSION="$ROCM_VERSION" \\
  --build-arg ROCM_REBUILD_RCCL="$ROCM_REBUILD_RCCL" \\
  --build-arg ROCM_SYSTEMS_REPO="$ROCM_SYSTEMS_REPO" \\
  --build-arg ROCM_SYSTEMS_COMMIT="$ROCM_SYSTEMS_COMMIT" \\
  --build-arg ROCM_LIBRARIES_REPO="$ROCM_LIBRARIES_REPO" \\
  --build-arg ROCM_LIBRARIES_COMMIT="$ROCM_LIBRARIES_COMMIT" \\
  --build-arg RCCL_GPU_TARGETS="$RCCL_GPU_TARGETS" \\
  --build-arg RCCL_TESTS_GPU_TARGETS="$RCCL_TESTS_GPU_TARGETS" \\
  --build-arg ROCM_PYPI_INDEX_URL="$ROCM_PYPI_INDEX_URL" \\
EOF
}

rocm_base_dotenv() {
  local rocm_variant_dir="${1:?rocm_variant_dir required}"

  cat <<EOF
ROCM_VARIANT_DIR=$rocm_variant_dir
ROCM_VERSION=$ROCM_VERSION
ROCM_REBUILD_RCCL=$ROCM_REBUILD_RCCL
ROCM_SYSTEMS_REPO=$ROCM_SYSTEMS_REPO
ROCM_SYSTEMS_COMMIT=$ROCM_SYSTEMS_COMMIT
ROCM_LIBRARIES_REPO=$ROCM_LIBRARIES_REPO
ROCM_LIBRARIES_COMMIT=$ROCM_LIBRARIES_COMMIT
RCCL_GPU_TARGETS=$RCCL_GPU_TARGETS
RCCL_TESTS_GPU_TARGETS=$RCCL_TESTS_GPU_TARGETS
ROCM_PYPI_INDEX_URL=$ROCM_PYPI_INDEX_URL
EOF
}

# Usage: rocm_base_refs NAME ROCM_VARIANT
# Returns: BASE_IMAGE_REF DOCKERFILE CANON_REF STABLE_REF
rocm_base_refs() {
  local rocm_name="${1:?rocm_name required}"       # e.g. pytorch
  local rocm_variant="${2:?rocm_variant required}" # e.g. rocm7.14-ubuntu24.04-py3.12-torch2.11

  : "${ALPS_REV:?ALPS_REV must be set}"
  : "${CSCS_CI_ORIG_CLONE_URL:?CSCS_CI_ORIG_CLONE_URL must be set}"

  local image_dir="Alps-Images/ROCm/${rocm_name}-${rocm_variant}"
  local profile_file
  profile_file="$(rocm_profile_file "$rocm_name" "$rocm_variant")"
  local dockerfile="Alps-Images/ROCm/Containerfile.rocm-alps"
  local rocm_installer="Alps-Images/ROCm/install-alps-rocm-stack.sh"
  local rocm_components="Alps-Images/ROCm/install-alps-rocm-components.sh"
  local rocm_runtime_env="Alps-Images/ROCm/alps-runtime.rocm.env"
  local common_dir="Alps-Images/common"
  local patches_dir="Alps-Images/patches"

  [[ -d "$image_dir" ]]    || { echo "ERROR: missing $image_dir" >&2; return 1; }
  [[ -f "$profile_file" ]] || { echo "ERROR: missing $profile_file" >&2; return 1; }
  [[ -f "$dockerfile" ]]   || { echo "ERROR: missing $dockerfile" >&2; return 1; }
  [[ -f "$rocm_installer" ]] || { echo "ERROR: missing $rocm_installer" >&2; return 1; }
  [[ -f "$rocm_components" ]] || { echo "ERROR: missing $rocm_components" >&2; return 1; }
  [[ -f "$rocm_runtime_env" ]] || { echo "ERROR: missing $rocm_runtime_env" >&2; return 1; }
  [[ -d "$common_dir" ]]   || { echo "ERROR: missing $common_dir" >&2; return 1; }
  [[ -d "$patches_dir" ]]  || { echo "ERROR: missing $patches_dir" >&2; return 1; }

  local ROCM_VERSION ROCM_PYPI_INDEX_URL ROCM_REBUILD_RCCL
  local ROCM_SYSTEMS_REPO ROCM_SYSTEMS_COMMIT RCCL_GPU_TARGETS RCCL_TESTS_GPU_TARGETS
  local ROCM_LIBRARIES_REPO ROCM_LIBRARIES_COMMIT
  load_rocm_profile "$profile_file"
  ROCM_VERSION="$(rocm_version_from_variant "$rocm_variant")"
  local base_image_ref
  base_image_ref="$(rocm_base_image_ref "$rocm_name" "$rocm_variant")"

  local -a hash_paths=("$dockerfile" "$rocm_installer" "$rocm_components" "$rocm_runtime_env" "$common_dir" "$patches_dir" "$image_dir")
  [[ ! -f .dockerignore ]] || hash_paths+=(.dockerignore)
  local name="${rocm_name}-rocm"
  local tag="${rocm_variant}-${ALPS_REV}"
  local h
  h="$(content_hash "name tag base_image_ref ROCM_VERSION ROCM_PYPI_INDEX_URL ROCM_REBUILD_RCCL ROCM_SYSTEMS_REPO ROCM_SYSTEMS_COMMIT ROCM_LIBRARIES_REPO ROCM_LIBRARIES_COMMIT RCCL_GPU_TARGETS RCCL_TESTS_GPU_TARGETS CSCS_CI_ORIG_CLONE_URL" "${hash_paths[@]}")"
  local canon_ref stable_ref
  read -r canon_ref stable_ref < <(image_refs "$name" "$tag" "$h")

  printf '%s %s %s %s\n' \
    "$base_image_ref" "$dockerfile" "$canon_ref" "$stable_ref"
}

# Usage: ngc_base_refs NGC_NAME NGC_TAG
ngc_base_refs() {
  local ngc_name="${1:?ngc_name required}"   # e.g. pytorch
  local ngc_tag="${2:?ngc_tag required}"     # e.g. 25.12-py3

  : "${ALPS_REV:?ALPS_REV must be set}"
  : "${CSCS_CI_ORIG_CLONE_URL:?CSCS_CI_ORIG_CLONE_URL must be set}"

  local image_dir="Alps-Images/NGC/${ngc_name}-${ngc_tag}"
  local profile_file="${image_dir}/profile.env"
  local dockerfile="Alps-Images/NGC/Containerfile.ngc-alps"
  local ngc_installer="Alps-Images/NGC/install-alps-cuda-stack.sh"
  local ngc_components="Alps-Images/NGC/install-alps-cuda-components.sh"
  local ngc_runtime_env="Alps-Images/NGC/alps-runtime.cuda.env"
  local common_dir="Alps-Images/common"
  local patches_dir="Alps-Images/patches"

  [[ -d "$image_dir" ]]    || { echo "ERROR: missing $image_dir" >&2; return 1; }
  [[ -f "$profile_file" ]] || { echo "ERROR: missing $profile_file" >&2; return 1; }
  [[ -f "$dockerfile" ]]   || { echo "ERROR: missing $dockerfile" >&2; return 1; }
  [[ -f "$ngc_installer" ]] || { echo "ERROR: missing $ngc_installer" >&2; return 1; }
  [[ -f "$ngc_components" ]] || { echo "ERROR: missing $ngc_components" >&2; return 1; }
  [[ -f "$ngc_runtime_env" ]] || { echo "ERROR: missing $ngc_runtime_env" >&2; return 1; }
  [[ -d "$common_dir" ]]   || { echo "ERROR: missing $common_dir" >&2; return 1; }
  [[ -d "$patches_dir" ]]  || { echo "ERROR: missing $patches_dir" >&2; return 1; }

  # Load optional NGC variant settings from profile file.
  local REMOVE_HPCX_DIRS=""
  local NVCR_PREFIX="nvidia"
  # shellcheck disable=SC1090
  source "$profile_file"
  REMOVE_HPCX_DIRS_B64="$(printf '%s' "$REMOVE_HPCX_DIRS" | base64 -w0)"
  # Keep the space-separated helper record parseable when the override is empty.
  [[ -n "$REMOVE_HPCX_DIRS_B64" ]] || REMOVE_HPCX_DIRS_B64="__EMPTY__"

  # Some nvcr images have a different repo structure, e.g. physicsnemo:
  # nvcr.io/nvidia/physicsnemo/physicsnemo:25.11
  # but most are like nvcr.io/nvidia/pytorch:25.12-py3, so we need to handle both cases.
  # NVCR_PREFIX defaults to "nvidia" unless overridden by the profile file.

  # BASE IMAGE points to NGC image via remote proxy (jfrog) (speed up downloads
  # in CI and avoid hitting NGC rate limits)
  local base_image_ref="jfrog.svc.cscs.ch/nvcr/${NVCR_PREFIX}/${ngc_name}:${ngc_tag}"

  # Compute canonical tag from hashed content
  local -a hash_paths=("$dockerfile" "$ngc_installer" "$ngc_components" "$ngc_runtime_env" "$common_dir" "$patches_dir" "$image_dir")
  [[ ! -f .dockerignore ]] || hash_paths+=(.dockerignore)
  local name="${ngc_name}-cuda"
  local tag="${ngc_tag}-${ALPS_REV}"
  local h
  h="$(content_hash "name tag base_image_ref REMOVE_HPCX_DIRS NVCR_PREFIX CSCS_CI_ORIG_CLONE_URL" "${hash_paths[@]}")"
  local canon_ref stable_ref
  read -r canon_ref stable_ref < <(image_refs "$name" "$tag" "$h")

  printf '%s %s %s %s %s\n' \
    "$base_image_ref" "$REMOVE_HPCX_DIRS_B64" "$dockerfile" "$canon_ref" "$stable_ref"
}

app_variant_prefix() {
  local app_variant="${1:?app variant required}"
  app_variant="${app_variant^^}"
  printf '%s\n' "${app_variant//-/_}"
}

# Derive the accelerator family from the selected logical base image.
app_base_family() {
  local base_image="${1:?base image required}"
  local parsed_base base_family family
  parsed_base="$(parse_base_image "$base_image")" || return 1
  base_family="${parsed_base%% *}"
  case "$base_family" in
    ngc) family=cuda ;;
    rocm) family=rocm ;;
    *)
      echo "ERROR: unsupported app base family: $base_family" >&2
      return 1
      ;;
  esac
  printf '%s\n' "$family"
}

# Read and validate all targets without executing the profile. Optionally require
# one requested target to be declared before callers normalize its name.
# Validation is profile-wide: malformed unselected targets or base declarations
# also block builds and ref/hash queries for an otherwise valid selected target.
app_variants_from_profile() {
  local profile_file="${1:?profile file required}"
  local requested_variant="${2:-}"
  local app_variants declared_variant prefix base_image family variant_name
  [[ -f "$profile_file" ]] || { echo "ERROR: missing $profile_file" >&2; return 1; }
  app_variants="$(profile_value "$profile_file" APP_VARIANTS)" || return 1
  [[ -n "${app_variants//[[:space:]]/}" ]] || {
    echo "ERROR: APP_VARIANTS must be set and not empty in $profile_file" >&2
    return 1
  }
  local -A prefixes=()

  for declared_variant in $app_variants; do
    [[ "$declared_variant" =~ ^[a-z_][a-z0-9_-]*$ ]] || {
      echo "ERROR: app target '${declared_variant}' in ${profile_file} must match ^[a-z_][a-z0-9_-]*$" >&2
      return 1
    }
    case "$declared_variant" in
      cuda|rocm|?*-cuda|?*-rocm) ;;
      *)
        echo "ERROR: app target '${declared_variant}' in ${profile_file} must be cuda, rocm, or end in -cuda/-rocm with a non-empty variant name" >&2
        return 1
        ;;
    esac
    variant_name="${declared_variant%-*}"
    if [[ "$declared_variant" != cuda && "$declared_variant" != rocm &&
          "$variant_name" =~ (^|[-_])(cuda|rocm)([-_]|$) ]]; then
      echo "ERROR: app target '${declared_variant}' in ${profile_file} must not contain cuda or rocm variant components before its family suffix" >&2
      return 1
    fi
    prefix="$(app_variant_prefix "$declared_variant")" || return 1
    if [[ -n "${prefixes[$prefix]+set}" ]]; then
      echo "ERROR: app variants '${prefixes[$prefix]}' and '${declared_variant}' share profile prefix ${prefix} in ${profile_file}" >&2
      return 1
    fi
    prefixes[$prefix]="$declared_variant"
    base_image="$(profile_value "$profile_file" "${prefix}_BASE_IMAGE")" || return 1
    [[ -n "$base_image" ]] || {
      echo "ERROR: ${prefix}_BASE_IMAGE must be set in ${profile_file}" >&2
      return 1
    }
    family="$(app_base_family "$base_image")" || return 1
    if [[ "$declared_variant" != "$family" && "$declared_variant" != *-"$family" ]]; then
      echo "ERROR: app target '${declared_variant}' does not match family '${family}' derived from base '${base_image}'" >&2
      return 1
    fi
  done

  if [[ -n "$requested_variant" ]]; then
    case " ${app_variants} " in
      *" ${requested_variant} "*) ;;
      *) echo "ERROR: app variant ${requested_variant} is not declared in ${profile_file}" >&2; return 1;;
    esac
  fi
  printf '%s\n' "$app_variants"
}

write_base_build_env() {
  local output_file="${1:?output file required}"
  local family="${2:?family required}"
  local name="${3:?name required}"
  local variant="${4:?variant required}"
  local base_image_ref dockerfile canon_image_ref stable_image_ref tested_image_ref image_description validation_hash_value
  local family_variant_dir="" family_dotenv=""

  : "${GHCR_IMAGE_PREFIX:?GHCR_IMAGE_PREFIX must be set}"
  : "${CI_COMMIT_SHORT_SHA:?CI_COMMIT_SHORT_SHA must be set}"

  case "$family" in
    cuda|ngc)
      read -r base_image_ref REMOVE_HPCX_DIRS_B64 dockerfile canon_image_ref stable_image_ref < <(ngc_base_refs "$name" "$variant")
      local remove_hpcx_dirs
      if [[ "$REMOVE_HPCX_DIRS_B64" == "__EMPTY__" ]]; then
        remove_hpcx_dirs=""
      else
        remove_hpcx_dirs="$(printf '%s' "$REMOVE_HPCX_DIRS_B64" | base64 -d)"
      fi
      family="cuda"
      image_description="This image extends ${base_image_ref} with a fully-optimized HPC networking stack tailored for the Alps supercomputer (legacy HPC-X components might be replaced)."
      family_variant_dir="NGC_VARIANT_DIR=${name}-${variant}"
      family_dotenv="REMOVE_HPCX_DIRS=${remove_hpcx_dirs}"
      ;;
    rocm)
      read -r base_image_ref dockerfile canon_image_ref stable_image_ref < <(rocm_base_refs "$name" "$variant")
      local profile_file ROCM_VERSION ROCM_PYPI_INDEX_URL ROCM_REBUILD_RCCL
      local ROCM_SYSTEMS_REPO ROCM_SYSTEMS_COMMIT RCCL_GPU_TARGETS RCCL_TESTS_GPU_TARGETS
      local ROCM_LIBRARIES_REPO ROCM_LIBRARIES_COMMIT
      profile_file="$(rocm_profile_file "$name" "$variant")"
      load_rocm_profile "$profile_file"
      ROCM_VERSION="$(rocm_version_from_variant "$variant")"
      image_description="This image extends ${base_image_ref} with a fully-optimized ROCm HPC networking stack tailored for the Alps supercomputer."
      family_dotenv="$(rocm_base_dotenv "${name}-${variant}")"
      ;;
    *)
      echo "ERROR: unsupported base family: $family" >&2
      return 1
      ;;
  esac

  # The generated child pipeline consumes one env record per variant. Keeping
  # this assembly in shell preserves identical canonical refs between CI,
  # publishing, and manual-build script generation.
  validation_hash_value="$(base_validation_hash "$family" "$name" "$variant")"
  tested_image_ref="$(tested_ref_for "$canon_image_ref" "$validation_hash_value")"

  {
    printf '%s\n' \
      "FAMILY=$family" \
      "NAME=$name" \
      "VARIANT=$variant" \
      "DOCKERFILE=$dockerfile" \
      "CANON_IMAGE_REF=$canon_image_ref" \
      "STABLE_IMAGE_REF=$stable_image_ref" \
      "TESTED_IMAGE_REF=$tested_image_ref" \
      "VALIDATION_HASH=$validation_hash_value" \
      "BASE_IMAGE=$base_image_ref"
    if [[ -n "$family_variant_dir" ]]; then
      printf '%s\n' "$family_variant_dir"
    fi
    if [[ -n "$family_dotenv" ]]; then
      printf '%s\n' "$family_dotenv"
    fi
    # shellcheck source=Alps-Images/common/alps-stack-versions.env
    source Alps-Images/common/alps-stack-versions.env
    vars_blob "BOOST_VER BOOST_BUILD_JOBS ALPS_BUILD_JOBS ALPS_CMAKE_BUILD_JOBS XPMEM_REF CASSINI_HEADERS_VERSION CXI_DRIVER_VERSION LIBCXI_VERSION LIBFABRIC_COMMIT LIBFABRIC_PATCH UCX_VERSION UCC_VERSION OMPI_VER AWS_OFI_NCCL_REPO AWS_OFI_NCCL_COMMIT AWS_OFI_NCCL_PATCH OSU_VERSION"
    printf '%s\n' \
      "OCI_SOURCE=${CSCS_CI_ORIG_CLONE_URL}" \
      "OCI_REVISION=${CI_COMMIT_SHA:-$CI_COMMIT_SHORT_SHA}" \
      "OCI_DESCRIPTION=$image_description" \
      "CSCS_ALPS_GIT_COMMIT_SHORT=${CI_COMMIT_SHORT_SHA}" \
      "GHCR_STABLE_IMAGE_REF=${GHCR_IMAGE_PREFIX}${stable_image_ref#"$IMAGE_PREFIX"}"
  } > "$output_file"
}

write_app_build_env() {
  local output_file="${1:?output file required}"
  local app_name="${2:?app name required}"
  local app_variant="${3:?app variant required}"
  local base_image_ref dockerfile canon_image_ref stable_image_ref tested_image_ref image_description validation_hash_value
  local family

  : "${GHCR_IMAGE_PREFIX:?GHCR_IMAGE_PREFIX must be set}"
  : "${CI_COMMIT_SHORT_SHA:?CI_COMMIT_SHORT_SHA must be set}"

  # App canonical hashes include the canonical base ref, so app images rebuild
  # automatically when their selected base content changes.
  read -r base_image_ref dockerfile canon_image_ref stable_image_ref family < <(app_refs "$app_name" "$app_variant") || return 1

  validation_hash_value="$(app_validation_hash "$app_name" "$app_variant")" || return 1
  tested_image_ref="$(tested_ref_for "$canon_image_ref" "$validation_hash_value")"
  image_description="This image extends ${base_image_ref} with application software for Alps."

  cat > "${output_file}" <<EOF
FAMILY=$family
VARIANT=$app_variant
DOCKERFILE=$dockerfile
CANON_IMAGE_REF=$canon_image_ref
STABLE_IMAGE_REF=$stable_image_ref
TESTED_IMAGE_REF=$tested_image_ref
VALIDATION_HASH=$validation_hash_value
BASE_IMAGE=$base_image_ref
OCI_SOURCE=${CSCS_CI_ORIG_CLONE_URL}
OCI_REVISION=${CI_COMMIT_SHA:-$CI_COMMIT_SHORT_SHA}
OCI_DESCRIPTION=$image_description
CSCS_ALPS_GIT_COMMIT_SHORT=${CI_COMMIT_SHORT_SHA}
GHCR_STABLE_IMAGE_REF=${GHCR_IMAGE_PREFIX}${stable_image_ref#"$IMAGE_PREFIX"}
EOF
}

# Usage: app_refs APP_NAME APP_VARIANT
# Returns a space-separated record:
#   BASE_IMAGE_REF DOCKERFILE CANON_REF STABLE_REF FAMILY
# FAMILY is the selected base's accelerator family: cuda (NGC) or rocm.
app_refs() {
  local app_name="${1:?name required}"       # e.g. vllm
  local app_variant="${2:?app variant required}" # e.g. cuda

  : "${ALPS_REV:?ALPS_REV must be set}"
  : "${CSCS_CI_ORIG_CLONE_URL:?CSCS_CI_ORIG_CLONE_URL must be set}"

  local app_dir="Alps-Images/apps/${app_name}"
  local profile_file="${app_dir}/profile.env"
  local package_helpers="Alps-Images/common/package-helpers.sh"
  local sources_dir="${app_dir}/sources"
  [[ -d "$app_dir" ]] || { echo "ERROR: missing $app_dir" >&2; return 1; }
  app_variants_from_profile "$profile_file" "$app_variant" >/dev/null || return 1
  local variant_upper
  variant_upper="$(app_variant_prefix "$app_variant")"
  local base_image_var="${variant_upper}_BASE_IMAGE"
  local dockerfile_var="${variant_upper}_CONTAINERFILE"
  local test_dir_var="${variant_upper}_TEST_DIR"
  local patch_dir_var="${variant_upper}_PATCH_DIR"

  local common_containerfile common_test_dir common_patch_dir
  common_containerfile="$(profile_value "$profile_file" COMMON_CONTAINERFILE)"
  common_test_dir="$(profile_value "$profile_file" COMMON_TEST_DIR)"
  common_patch_dir="$(profile_value "$profile_file" COMMON_PATCH_DIR)"

  local base_image
  local dockerfile_rel
  local test_dir_rel
  local patch_dir_rel
  base_image="$(profile_value "$profile_file" "$base_image_var")"
  dockerfile_rel="$(profile_value "$profile_file" "$dockerfile_var")"
  test_dir_rel="$(profile_value "$profile_file" "$test_dir_var")"
  patch_dir_rel="$(profile_value "$profile_file" "$patch_dir_var")"
  dockerfile_rel="${dockerfile_rel:-${common_containerfile:-Containerfile}}"
  local dockerfile
  local -a test_dirs=() patch_dirs=()

  dockerfile="${app_dir}/${dockerfile_rel}"
  [[ -f "$dockerfile" ]] || { echo "ERROR: missing $dockerfile" >&2; return 1; }

  if [[ -n "$common_test_dir" ]]; then
    local common_test_path="${app_dir}/${common_test_dir}"
    [[ -d "$common_test_path" ]] || { echo "ERROR: missing declared common test dir $common_test_path" >&2; return 1; }
    test_dirs+=("$common_test_path")
  fi
  if [[ -n "$test_dir_rel" ]]; then
    local test_dir="${app_dir}/${test_dir_rel}"
    [[ -d "$test_dir" ]] || { echo "ERROR: missing declared test dir $test_dir" >&2; return 1; }
    test_dirs+=("$test_dir")
  fi
  if [[ -n "$common_patch_dir" ]]; then
    local common_patch_path="${app_dir}/${common_patch_dir}"
    [[ -d "$common_patch_path" ]] || { echo "ERROR: missing declared common patch dir $common_patch_path" >&2; return 1; }
    patch_dirs+=("$common_patch_path")
  fi
  if [[ -n "$patch_dir_rel" ]]; then
    local patch_dir="${app_dir}/${patch_dir_rel}"
    [[ -d "$patch_dir" ]] || { echo "ERROR: missing declared patch dir $patch_dir" >&2; return 1; }
    patch_dirs+=("$patch_dir")
  fi

  # Compute canonical ref of base
  local base_family base_name base_variant
  read -r base_family base_name base_variant < <(parse_base_image "$base_image")
  local family
  family="$(app_base_family "$base_image")" || return 1
  local base_canon_ref
  base_canon_ref="$(base_canonical_ref "$base_family" "$base_name" "$base_variant")"

  # Hash the selected profile values, not unrelated build-target settings.
  local -a hash_paths=("$dockerfile" "${patch_dirs[@]}" "${test_dirs[@]}")
  # Explicit file lists narrow target-specific helper inputs. Apps without
  # lists retain automatic coverage of their complete sources directory.
  local common_sources variant_sources source_rel
  common_sources="$(profile_value "$profile_file" COMMON_SOURCE_FILES)"
  variant_sources="$(profile_value "$profile_file" "${variant_upper}_SOURCE_FILES")"
  if [[ -n "${common_sources}${variant_sources}" ]]; then
    local -a source_files=()
    read -r -a source_files <<< "${common_sources} ${variant_sources}"
    for source_rel in "${source_files[@]}"; do
      [[ -f "${app_dir}/${source_rel}" ]] || { echo "ERROR: missing declared source file ${app_dir}/${source_rel}" >&2; return 1; }
      hash_paths+=("${app_dir}/${source_rel}")
    done
  elif [[ -d "$sources_dir" ]]; then
    hash_paths+=("$sources_dir")
  fi
  [[ ! -f .dockerignore ]] || hash_paths+=(.dockerignore)
  if grep -Fq "$package_helpers" "$dockerfile"; then
    [[ -f "$package_helpers" ]] || { echo "ERROR: missing $package_helpers" >&2; return 1; }
    hash_paths+=("$package_helpers")
  fi
  local image_name="${app_name}-${app_variant}"
  local tag="${ALPS_REV}"
  local h
  # Profile-key coverage and effective/defaulted values are documented in README.md.
  # Hash the resolved base ref only; base_image is just its profile selector.
  h="$(content_hash "app_name app_variant image_name tag base_canon_ref dockerfile_rel common_test_dir test_dir_rel common_patch_dir patch_dir_rel common_sources variant_sources CSCS_CI_ORIG_CLONE_URL" "${hash_paths[@]}")"
  local canon_ref stable_ref
  read -r canon_ref stable_ref < <(image_refs "$image_name" "$tag" "$h")

  printf '%s %s %s %s %s\n' "$base_canon_ref" "$dockerfile" "$canon_ref" "$stable_ref" "$family"
}
