[![build-images](https://gitlab.com/cscs-ci/ci-testing/webhook-ci/mirrors/4655938191952498/3557919080247023/badges/main/pipeline.svg?ignore_skipped=true&key_text=build-images&key_width=90)](https://gitlab.com/cscs-ci/ci-testing/webhook-ci/mirrors/4655938191952498/3557919080247023/-/pipelines?ref=main)

# Alps Extended Images

Container images that extend NVIDIA NGC and AMD ROCm base images with a fully-optimized HPC networking stack tailored for the [Alps supercomputer](https://www.cscs.ch/computers/alps) at [CSCS](https://www.cscs.ch).
The images replace generic bundled communication components with libraries compiled specifically for the Slingshot CXI interconnect, enabling efficient GPU-accelerated collective communication across the Alps fabric.

Image pipeline managed via: https://cicd-ext-mw.cscs.ch

## Overview

Vendor GPU framework images ship with generic HPC libraries that are not optimized for the Slingshot network fabric used on Alps.
This project rebuilds the relevant HPC networking stack — libfabric, NCCL/RCCL plugins, UCX, UCC, OpenMPI, and accelerator-specific components — against the CXI provider and installs the result on top of each supported base image.

The resulting images are validated on multi-node Slurm allocations before being promoted to stable registries.
CUDA images run on Clariden GH200; ROCm images run on Beverin MI300.

## Image Variants

### CUDA Base Images

Each variant corresponds to an NGC CUDA container extended with the Alps HPC stack:

| Image | NGC Base | Use Case |
|---------|----------|----------|
| `pytorch-cuda:26.07-py3-alps7-dev` | `nvcr.io/nvidia/pytorch:26.07-py3`             | GPU-accelerated PyTorch workloads |
| `pytorch-cuda:26.06-py3-alps7-dev` | `nvcr.io/nvidia/pytorch:26.06-py3`             | GPU-accelerated PyTorch workloads |
| `pytorch-cuda:26.02-py3-alps7-dev` | `nvcr.io/nvidia/pytorch:26.02-py3`             | GPU-accelerated PyTorch workloads |
| `pytorch-cuda:26.01-py3-alps7-dev` | `nvcr.io/nvidia/pytorch:26.01-py3`             | GPU-accelerated PyTorch workloads |
| `pytorch-cuda:25.12-py3-alps7-dev` | `nvcr.io/nvidia/pytorch:25.12-py3`             | GPU-accelerated PyTorch workloads |
| `nemo-cuda:25.11.01-alps7-dev`     | `nvcr.io/nvidia/nemo:25.11.01`                 | Speech & language model training  |
| `nemo-cuda:26.02-alps7-dev`        | `nvcr.io/nvidia/nemo:26.02`                    | Speech & language model training  |
| `physicsnemo-cuda:25.11-alps7-dev` | `nvcr.io/nvidia/physicsnemo/physicsnemo:25.11` | Physics-informed neural networks  |

### ROCm Base Images

Each variant corresponds to an AMD ROCm container extended with the Alps HPC stack:

| Image | ROCm Base | Use Case |
|-------|-----------|----------|
| `pytorch-rocm:rocm10.0-ubuntu24.04-py3.12-torch2.13-alps7-dev` | `docker.io/rocm/pytorch:rocm10.0_ubuntu24.04_py3.12_pytorch_release_2.13.0` | ROCm PyTorch workloads on MI300-class systems |
| `pytorch-rocm:rocm7.14-ubuntu24.04-py3.12-torch2.11-alps7-dev` | `docker.io/rocm/pytorch:rocm7.14_ubuntu24.04_py3.12_pytorch_release_2.11.0` | ROCm PyTorch workloads on MI300-class systems |

### Application Images

Application images are built on top of accelerator-specific base images and include additional software for specific workloads.
CUDA app variants are available for the listed workloads; ROCm app variants are added when the app explicitly opts in with its own Containerfile and tests.

| Image | Base | Description |
|-------|------|-------------|
| `apertus-1p5-cuda:alps7-dev` | `pytorch-cuda:26.02-py3` | Megatron-LM distributed LLM pretraining |
| `apertus-2-cuda:alps7-dev`   | `pytorch-cuda:26.02-py3` | Multi-model ML benchmark suite (pplx-garden, DeepEP, quack-kernels) |
| `sfttrainer-cuda:alps7-dev`  | `pytorch-cuda:26.02-py3` | Supervised fine-tuning trainer image |
| `verl-cuda:alps7-dev`        | `pytorch-cuda:26.02-py3` | VeRL reinforcement learning workloads |
| `vllm-cuda:alps7-dev`        | `pytorch-cuda:26.07-py3` | vLLM serving workloads built from source (v0.31.0, Torch 2.13 stable-libtorch APIs), with UCCL-EP and Mooncake CXI KV transfer over Slingshot CXI |
| `vllm-rocm:alps7-dev`        | `pytorch-rocm:rocm10.0-ubuntu24.04-py3.12-torch2.13` | vLLM serving workloads built from source for ROCm/MI300 (v0.31.0), with AITER, UCCL-EP, and Mooncake CXI KV transfer over Slingshot CXI |

## HPC Stack Components

The base installers use shared defaults from `common/alps-stack-versions.env`, shared build primitives from `common/install-alps-hpc-stack.sh`, plus family-specific wrappers from `NGC/` or `ROCm/`.
They purge preinstalled generic network-stack packages/files where appropriate, then build and install the following libraries.
Shared primitives export `LIBFABRIC_PREFIX`, `UCX_PREFIX`, `UCC_PREFIX`, `OMPI_PREFIX`, and `HWLOC_PREFIX`; shared aws-ofi plugin logic is configured by the family wrappers with CUDA or ROCm support.

| Component | Version | Purpose |
|-----------|---------|---------|
| libfabric (CXI provider) | 2.6.0 | High-speed network fabric abstraction for Slingshot |
| NCCL | 2.30.7-1 | NVIDIA collective communications (allreduce, alltoall, …) |
| aws-ofi-nccl | 1.20.0 | Routes NCCL traffic over libfabric/OFI |
| NVSHMEM | 3.6.5-0 | GPU symmetric heap memory for peer-to-peer transfers |
| UCX | 1.20.1 | Unified Communication X transport layer |
| UCC | 1.8.0 | Unified Collective Communications abstraction |
| OpenMPI | 5.0.10 | MPI implementation linked against OFI and UCX |
| GDRCopy | 2.5.1 | GPU Direct RDMA copy utilities |
| XPMEM | — | Cross-process memory regions for intra-node GPU sharing |
| NCCL Tests | 2.18.2 | Collective benchmark suite |
| OSU Micro-benchmarks | 7.5.2 | Point-to-point latency and bandwidth measurements |

CUDA components are compiled with CUDA support and architecture-specific flags for NVIDIA Hopper (SM90/SM90a).
ROCm components keep the bundled RCCL by default, build aws-ofi-rccl against the Alps libfabric stack, and build rccl-tests for the profile's selected targets: ROCm 7.14 retains MI250/MI300 (`gfx90a`, `gfx942`); the ROCm 10.0 profile targets MI300 (`gfx942`).
ROCm 10.0 image coverage for `gfx90a` is not established.
RCCL rebuilds are opt-in with `ROCM_REBUILD_RCCL=1`.

The ROCm 10.0 base ships only runtime SDK wheels (there is no public `rocm-sdk-devel` for ROCm 10), so its profile pins the matching `rocm-libraries` source tag (`ROCM_LIBRARIES_REPO`/`ROCM_LIBRARIES_COMMIT`) and the build generates the missing devel payload from it: CMake package configs for every package torch's `LoadHIP` requires, the public math-library headers, and dev-name library symlinks, mirrored at both `/opt/rocm` and the wheel install prefix.
ROCm 7.x profiles use the real `rocm-sdk-devel` wheel instead and need no such pin.

ROCm build-prefix discovery prefers an explicit devel prefix, then the assembled `/opt/rocm` compatibility view, before probing runtime wheels.
Runtime `ldconfig` discovery remains wheel-first so Torch and other consumers do not load duplicate LLVM libraries.

The ROCm 10 compatibility payload includes MIOpen's public C API headers, generated version/export headers and HIP backend configuration in both SDK include layouts.
It retains the wheel's MIOpen runtime rather than installing a second copy.
The build checks the pinned header version against `miopenGetVersion`; base environment validation compiles and links a consumer, creates a GPU handle, and compares an explicit MIOpen convolution with a CPU reference.
MIOpen's private C++ implementation headers are not installed.
The public source-header allowlist is `miopen.h`, `config.h.in`, and `version.h.in`; missing or unexpected files and directories stop the build for review.

RCCL builds and `rccl-tests` share SDK compiler discovery: prefer `${ROCM_SDK_BIN}/amdclang++`, falling back to `${ROCM_CORE_PREFIX}/lib/llvm/bin/clang++` for wheel-only layouts.
The test build passes that compiler explicitly to CMake instead of relying on the upstream toolchain's conventional `ROCM_PATH/llvm/bin/amdclang++` path.

The wheel-only layout exposes the SDK's real `lib/llvm/amdgcn` payload through both `/opt/rocm/amdgcn` and `${ROCM_CORE_PREFIX}/amdgcn`.
The latter is necessary when `ROCM_PATH` explicitly selects the core wheel prefix: clang then searches that prefix for HIP device bitcode rather than falling back to `/opt/rocm`.
Missing `ocml.bc` or `ockl.bc` stops bootstrap with an explicit error; device-library linking is not disabled.

SDK distributions, including device wheels, must match the profile's ROCm base release; matching nightly/development builds are retained.
Profiles without pinned compatibility sources install the real devel wheel when it is absent and fail if installation fails.
Compatibility builds shallow-fetch the pinned sources and derive component versions from their upstream CMake declarations and header templates rather than assigning SDK versions to every library.
They refuse to replace an existing `/opt/rocm` directory or symlink unless it is an installer-owned compatibility tree.
ROCm 10-specific rccl-tests compiler workarounds do not modify ROCm 7.14 sources.

Patches for upstream issues in libfabric, NCCL, and aws-ofi-nccl are maintained under `Alps-Images/patches/` and are included in base image hashes.
Application-specific patches are kept under `Alps-Images/apps/<app>/patches/` and are included in app image hashes.

## Runtime Environment

Runtime environment fragments configure Slingshot-based collective communication.
NGC images assemble `common/alps-runtime.common.env`, `common/alps-runtime.nccl-like.env`, and `NGC/alps-runtime.cuda.env`; ROCm images assemble `common/alps-runtime.common.env`, `common/alps-runtime.nccl-like.env`, and `ROCm/alps-runtime.rocm.env` into `/opt/alps/env/alps-runtime.env`:

- **NCCL/RCCL-compatible defaults**: uses the AWS libfabric transport (`NCCL_NET=AWS Libfabric`) and Slingshot-oriented NIC/socket/protocol/channel tuning
- **NCCL/CUDA-specific defaults**: NVIDIA topology/GDR tuning and CUDA/NVSHMEM settings
- **NCCL plugin cleanup**: clears inherited `NCCL_NET_PLUGIN` settings so NCCL can use the Alps libfabric plugin selected by `NCCL_NET`
- **CXI / libfabric**: provider selection, memory registration caching, rendezvous and RX match-mode settings
- **NVSHMEM**: libfabric remote transport over the Cassini provider, CUDA VMM disabled
- **OpenMPI / PMIX**: security modules, byte transfer layer restricted to supported backends
- **CUDA**: JIT cache disabled for shared-filesystem compatibility

Both shipped ROCm profiles default `NCCL_P2P_DISABLE=1` in Podman and Sarus/Enroot; the earlier runtime-specific exception was removed because the Sarus results were inconclusive.
Explicit user values, including an empty value, remain unchanged.

## CI/CD Pipeline

The GitLab entry point is `ci-pipelines/build-alps-extended-images.yaml`.
It generates a child pipeline at runtime because the required work depends on registry state: missing canonical images are built, images without a current tested marker are validated, and validated images with stale or missing stable refs are published.
If all images are current, the child pipeline contains only a lightweight `no-work-required` job.

Canonical build jobs use project-wide resource-group locks keyed by a SHA-256 hash of the full canonical image reference (registry, repository, and tag).
Identical references share a lock across PRs and pipelines; different canonical images can build concurrently, including different versions of the same variant.
After acquiring the lock, each job re-checks the registry and skips its build if another pipeline has already published that image.
Digest mismatches remain hard failures.

The generated child pipeline can contain these stages:

1. **build-base** — builds missing CUDA and ROCm HPC-extended canonical base images
2. **test-base** — validates base images on Slurm allocations with environment checks, collective benchmarks, CUDA `vetnode`, and ROCm/PyTorch smoke tests
3. **mark-base-tested** — creates tested-marker tags for base images that passed the current validation
4. **build-apps** — builds missing application images on top of validated canonical base image refs
5. **test-apps** — runs app workload tests and app `vetnode` coverage declared in app-local `ci.yaml` files
6. **mark-app-tested** — creates tested-marker tags for app images that passed the current validation
7. **publish** — promotes validated images to stable JFrog and GHCR refs while preserving stable-tag immutability rules

**Image tagging strategy:** canonical image tags include deterministic content hashes, allowing the pipeline to detect unchanged inputs and skip unnecessary rebuilds.
App hashes include the accelerator variant, canonical base image ref, selected Containerfile and profile values, declared tests and patches, source files, and copied shared helpers.
Base hashes include the selected family/profile, shared stack inputs, and the complete shared patch tree recursively, so new patch directories are covered automatically.
The root `.dockerignore` policy is also hashed.
Tested-marker tags have the form `<canonical-tag>-tested-<validation-hash>` and are valid only when they point to the same digest as the canonical image.

**Build-cache policy:**

- OCI timestamps and commit metadata are applied after software installation in every base and app image.
  A final no-op `RUN` makes metadata changes visible to Podman's label cache without rerunning expensive builds.
  The generator image has only static labels.
- App profile hashes use only the selected build target's settings; see [App profile hash coverage](#app-profile-hash-coverage) for supported keys and source-file defaults.
- The repository-root `.dockerignore` excludes Git metadata, Python caches, and editor scratch files without restricting source directories.
  These transient files are also excluded from recursive content hashing.
- Base patch changes can invalidate both accelerator families' canonical refs.
  Component-specific `COPY` instructions still allow unaffected build layers to be reused.
- Changing a canonical base or an earlier installed component still invalidates dependent layers.
  Containerfile and hash-policy changes require a one-time canonical-image rebuild; timestamps and commit SHAs remain excluded from content hashes.

### App profile hash coverage

`app_refs` reads the following app `profile.env` keys instead of hashing the complete profile file.
`APP_VARIANTS` contains flat build targets: legacy `cuda` / `rocm`, or family-qualified names ending in `-cuda` / `-rocm`.
Target names must be lowercase and match `^[a-z_][a-z0-9_-]*$`.
In qualified targets, `cuda` and `rocm` are reserved for the final family suffix and cannot appear as hyphen- or underscore-delimited components in the variant name; for example, `cuda-rocm`, `rocm-cuda`, and `team_cuda-rocm` are rejected.
`<TARGET>` is the selected target uppercased with `-` replaced by `_`; for example, hypothetical `example-stage-cuda` settings use the `EXAMPLE_STAGE_CUDA` prefix.
The selected base determines the accelerator family, and contradictory suffixes or colliding normalized prefixes are rejected.
Validation covers every declared target and base selector, so a malformed unselected target or base declaration also blocks selected-target builds and ref/hash queries.

`app_refs APP_NAME APP_VARIANT` returns one space-separated five-field record: `BASE_IMAGE_REF DOCKERFILE CANON_REF STABLE_REF FAMILY`.
`FAMILY` is the selected base's accelerator family (`cuda` or `rocm`), while `BASE_IMAGE_REF` is its canonical image ref.

| Profile keys | Content-hash coverage |
| --- | --- |
| `<TARGET>_BASE_IMAGE` | Resolved canonical base ref; the raw selector is not hashed separately. |
| `COMMON_CONTAINERFILE`, `<TARGET>_CONTAINERFILE` | Effective selected path and file contents; target override, then common value, then `Containerfile`. |
| `COMMON_TEST_DIR`, `<TARGET>_TEST_DIR` | Both declared paths and their recursive contents. |
| `COMMON_PATCH_DIR`, `<TARGET>_PATCH_DIR` | Both declared paths and their recursive contents. |
| `COMMON_SOURCE_FILES`, `<TARGET>_SOURCE_FILES` | Both selected lists and file contents; if both lists are empty, an existing `sources/` directory is hashed recursively. |
| `APP_VARIANTS` | Validates target eligibility and base-family agreement; the full list is not hashed, but the selected target is. |

Source lists are whitespace-separated, app-relative files and must cover every source file copied for that target.
Other logical hash inputs are the app name, selected target, derived image name, `ALPS_REV`, and `CSCS_CI_ORIG_CLONE_URL`.
Containerfile, patch, test, source, copied package-helper, and `.dockerignore` contents are hashed as described above.

When adding a build-affecting profile key, update its reader, hash inputs, this contract, and target-invalidation regression coverage together.
Valid unselected target settings do not invalidate the selected image's content hash.

App tests declared with `kind: cuda-vetnode` always use the fixed CUDA runner and accept only `name` and `kind`; they cannot set `runner` or run on ROCm bases.
Custom app tests may still select a `runner`, defaulting to the selected base's family.

## Manual Builds

Images can be built manually on Alps with `podman` using generated build scripts that reuse the CI image-reference logic.
See `manual-build/README.md`.

## Acknowledgements

Alps extended base images have been developed in collaboration with the Swiss AI engineers.
Special thanks to [@EduardDurech](https://github.com/EduardDurech) for the many contributions ranging from discovering bottlenecks and major bugs to patching underlying libraries.
