#!/bin/bash
set -euo pipefail
cd /iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/runtime/source-589ddd593f62
export PYTHONPATH=/iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/runtime/source-589ddd593f62/methods/eagle:/iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/runtime/source-589ddd593f62/src
export PATH=/users/faruk_zahiragic/venvs/sml-apertus/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
exec python3 -u -m apertus_eagle.adaptation_recovery \
  --repo /iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/runtime/source-589ddd593f62 \
  --campaign-root /iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache \
  --trace-job 3804324 --run-id recovery-20261030-cache --poll-seconds 120
