#!/bin/bash
set -euo pipefail
cd /iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/runtime/source-379c7c15cc50
export PYTHONPATH=/iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/runtime/source-379c7c15cc50/methods/eagle:/iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/runtime/source-379c7c15cc50/src
export PATH=/users/faruk_zahiragic/venvs/sml-apertus/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
export TMPDIR=/iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/submission-tmp/controller-379c7c15cc50
exec python3 -u -m apertus_eagle.adaptation_recovery \
  --repo /iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/runtime/source-379c7c15cc50 \
  --campaign-root /iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache \
  --trace-job 3804324 --run-id recovery-20261030-cache --poll-seconds 120 --confirmation-only --confirmation-attempt repair-20261031
