#!/bin/bash
set -euo pipefail
cd /iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/runtime/source-7f0a41dcc0a3
export PYTHONPATH=/iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/runtime/source-7f0a41dcc0a3/methods/eagle:/iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/runtime/source-7f0a41dcc0a3/src
export PATH=/users/faruk_zahiragic/venvs/sml-apertus/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
export TMPDIR=/iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/submission-tmp/controller-7f0a41dcc0a3
exec python3 -u -m apertus_eagle.adaptation_recovery \
  --repo /iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache/runtime/source-7f0a41dcc0a3 \
  --campaign-root /iopsstor/scratch/cscs/faruk_zahiragic/spec-exp-data/drafter-updates/recovery-20261030-cache \
  --trace-job 3804324 --run-id recovery-20261030-cache --poll-seconds 120 --confirmation-only --confirmation-attempt repair-20261031c --confirmation-wall-time 12:00:00
